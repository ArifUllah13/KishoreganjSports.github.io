# Kishoreganj Sports - District Sports Portal

A comprehensive sports portal for Kishoreganj District featuring players, teams, rankings, schedules, and latest sports news across all sports including Cricket, Football, Badminton, and Volleyball.

## 🏆 Features

### **Core Features**
- **Multi-Sport Coverage**: Cricket, Football, Badminton, Volleyball, and more
- **Player Profiles**: Detailed player information with stats and records
- **Team Information**: Complete team profiles with achievements
- **Live Rankings**: Real-time player and team rankings
- **Match Schedules**: Upcoming and completed matches with live status
- **Sports News**: Latest news and updates from the district
- **Advanced Search**: Search across all content types
- **Dynamic Filtering**: Sport-specific filters and categories

### **Technical Features**
- **Responsive Design**: Works perfectly on mobile, tablet, and desktop
- **Real-time Updates**: Live countdown timers for upcoming matches
- **Interactive Popups**: Detailed player, team, and match information
- **Navigation System**: Intuitive navigation with dropdown menus
- **Modern UI**: Built with Next.js 15, TypeScript, and Tailwind CSS
- **Component Library**: Uses shadcn/ui components for consistency

### **Special Features**
- **Countdown Timers**: Live countdown for upcoming matches
- **Match Status**: Real-time match status (Upcoming, Live, Completed)
- **Detail Popups**: Comprehensive information modals for players, teams, and matches
- **Sport-Specific Filters**: Dynamic filtering based on selected sport
- **Blogger Template**: Complete XML template for Blogger integration

## 🚀 Getting Started

### **Prerequisites**
- Node.js 18+ 
- npm or yarn
- Modern web browser

### **Installation**

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/kishoreganj-sports.git
   cd kishoreganj-sports
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Run the development server**
   ```bash
   npm run dev
   # or
   yarn dev
   ```

4. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### **Build for Production**

```bash
npm run build
npm start
```

## 📁 Project Structure

```
kishoreganj-sports/
├── src/
│   ├── app/
│   │   ├── page.tsx              # Home page with highlights
│   │   ├── players/
│   │   │   └── page.tsx          # Players directory page
│   │   ├── teams/
│   │   │   └── page.tsx          # Teams directory page
│   │   ├── rankings/
│   │   │   └── page.tsx          # Rankings page
│   │   ├── schedules/
│   │   │   └── page.tsx          # Schedules page
│   │   ├── news/
│   │   │   └── page.tsx          # News page
│   │   ├── layout.tsx            # Root layout
│   │   └── globals.css           # Global styles
│   ├── components/
│   │   ├── ui/                   # shadcn/ui components
│   │   └── CountdownTimer.tsx    # Countdown timer component
│   ├── lib/
│   │   ├── utils.ts              # Utility functions
│   │   ├── db.ts                 # Database client
│   │   └── socket.ts             # Socket.io logic
│   └── hooks/
│       ├── use-toast.ts          # Toast hook
│       └── use-mobile.ts         # Mobile detection hook
├── public/
│   ├── sitemap.xml              # SEO sitemap
│   ├── logo.svg                 # Site logo
│   └── favicon.ico              # Site favicon
├── prisma/
│   └── schema.prisma            # Database schema
├── kishoreganj-sports-blogger-template.xml  # Blogger template
├── package.json
├── tailwind.config.ts
├── next.config.ts
└── README.md
```

## 🎯 Pages Overview

### **Home Page (`/`)**
- Featured statistics dashboard
- Highlighted players and teams
- Upcoming matches preview
- Latest news section
- Quick navigation to all sections

### **Players Page (`/players`)**
- Complete player directory
- Advanced filtering by sport and player type
- Detailed player profiles with stats
- Search functionality
- Player achievement records

### **Teams Page (`/teams`)**
- Team directory with performance stats
- Team achievements and history
- Captain and squad information
- Home ground details
- Win/loss records

### **Rankings Page (`/rankings`)**
- Player and team rankings
- Filter by ranking type and sport
- Position change indicators
- Points system display
- Real-time ranking updates

### **Schedules Page (`/schedules`)**
- Match schedules and fixtures
- Live countdown timers
- Match status tracking
- Detailed match information
- Scorecard and squad details

### **News Page (`/news`)**
- Latest sports news and updates
- Categorized by sport
- Featured articles
- Author and publication info
- Read time and view counts

## 🛠️ Technologies Used

### **Frontend**
- **Next.js 15**: React framework with App Router
- **TypeScript**: Type-safe JavaScript
- **Tailwind CSS**: Utility-first CSS framework
- **shadcn/ui**: Modern component library
- **Lucide React**: Icon library
- **Framer Motion**: Animations (optional)

### **Backend**
- **Node.js**: Runtime environment
- **Prisma**: ORM for database operations
- **SQLite**: Database (client-only)
- **Socket.io**: Real-time communication

### **Development Tools**
- **ESLint**: Code linting
- **Tailwind CSS**: Styling
- **PostCSS**: CSS processing
- **TypeScript**: Type checking

## 🎨 Design System

### **Color Palette**
- **Primary**: Green (#059669) - Sports theme
- **Secondary**: Blue (#2563eb) - Trust and professionalism
- **Accent**: Orange (#ea580c) - Energy and excitement
- **Neutral**: Gray shades for text and backgrounds

### **Typography**
- **Font Family**: Geist (modern, clean)
- **Headings**: Bold, hierarchical sizing
- **Body**: Clean, readable text
- **Responsive**: Scales appropriately on all devices

### **Components**
- **Cards**: Consistent styling for content blocks
- **Badges**: Sport and status indicators
- **Buttons**: Clear call-to-action elements
- **Modals**: Detailed information displays
- **Navigation**: Intuitive menu system

## 📱 Responsive Design

The website is fully responsive and optimized for:
- **Mobile**: 320px+ - Touch-friendly interface
- **Tablet**: 768px+ - Balanced layout
- **Desktop**: 1024px+ - Full feature experience
- **Large Desktop**: 1280px+ - Enhanced spacing

## 🔧 Configuration

### **Environment Variables**
Create a `.env.local` file for environment-specific configuration:

```env
NEXT_PUBLIC_APP_URL=http://localhost:3000
DATABASE_URL="file:./dev.db"
```

### **Customization**
- **Colors**: Modify `tailwind.config.ts`
- **Components**: Update shadcn/ui components
- **Layout**: Modify `src/app/layout.tsx`
- **Styles**: Update `src/app/globals.css`

## 📝 Blogger Integration

The project includes a complete Blogger template (`kishoreganj-sports-blogger-template.xml`) that can be uploaded to Blogger for a consistent experience across platforms.

### **Blogger Template Features**
- Responsive design
- Widget support
- Custom styling
- SEO optimized
- Social media integration

## 🚀 Deployment

### **Vercel (Recommended)**
1. Push code to GitHub
2. Connect repository to Vercel
3. Deploy automatically

### **Netlify**
1. Build the project: `npm run build`
2. Upload `out` folder to Netlify
3. Configure domain and settings

### **Static Export**
```bash
npm run build
npm run export
```

## 🤝 Contributing

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```
3. **Commit your changes**
   ```bash
   git commit -m 'Add amazing feature'
   ```
4. **Push to the branch**
   ```bash
   git push origin feature/amazing-feature
   ```
5. **Open a Pull Request**

### **Development Guidelines**
- Follow the existing code style
- Use TypeScript for type safety
- Write clear, descriptive commit messages
- Test your changes thoroughly
- Update documentation as needed

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Kishoreganj District Sports Community**
- **Local athletes and teams**
- **Sports enthusiasts and supporters
- **Open source contributors**

## 📞 Support

For support and questions:
- **Email**: info@kishoreganjsports.com
- **GitHub Issues**: Create an issue for bug reports or feature requests
- **Discussions**: Join our community discussions

## 🎯 Roadmap

### **Phase 1** (Current)
- ✅ Basic sports portal
- ✅ Player and team directories
- ✅ Match schedules and rankings
- ✅ News section
- ✅ Responsive design

### **Phase 2** (Future)
- 🔄 User authentication system
- 🔄 Live match scoring
- 🔄 Mobile app development
- 🔄 Social media integration
- 🔄 Advanced analytics

### **Phase 3** (Long-term)
- 🔄 E-commerce for merchandise
- 🔄 Video streaming integration
- 🔄 AI-powered insights
- 🔄 Multi-language support
- 🔄 International expansion

---

**Built with ❤️ for Kishoreganj District Sports Community**