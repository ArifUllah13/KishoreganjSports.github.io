'use client'

import { useState } from 'react'
import { Search, Filter, Calendar, Play, Pause, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import Link from 'next/link'
import CountdownTimer from '@/components/CountdownTimer'

const mockSchedules = [
  { 
    id: 1, 
    team1: 'Kishoreganj Tigers', 
    team2: 'Kishoreganj Lions', 
    sport: 'cricket', 
    format: 'T20', 
    date: '2024-01-15', 
    time: '14:00', 
    venue: 'Kishoreganj Stadium',
    status: 'upcoming',
    startTime: new Date('2024-01-15T14:00:00').getTime(),
    scorecard: {
      team1Score: '0/0',
      team2Score: '0/0',
      overs: '0/20',
      status: 'Match starts at 2:00 PM'
    },
    squads: {
      team1: ['Rahim Khan', 'Karim Ahmed', 'Jamal Hossain', 'Salam Uddin', 'Rupa Akter'],
      team2: ['Player 1', 'Player 2', 'Player 3', 'Player 4', 'Player 5']
    }
  },
  { 
    id: 2, 
    team1: 'Kishoreganj United', 
    team2: 'Kishoreganj City', 
    sport: 'football', 
    format: 'League', 
    date: '2024-01-16', 
    time: '16:00', 
    venue: 'District Football Ground',
    status: 'upcoming',
    startTime: new Date('2024-01-16T16:00:00').getTime(),
    scorecard: {
      team1Score: '0',
      team2Score: '0',
      overs: '0\'',
      status: 'Match starts at 4:00 PM'
    },
    squads: {
      team1: ['Salam Uddin', 'Jamal Hossain', 'Player 3', 'Player 4', 'Player 5'],
      team2: ['Player 1', 'Player 2', 'Player 3', 'Player 4', 'Player 5']
    }
  },
  { 
    id: 3, 
    team1: 'Kishoreganj Smashers', 
    team2: 'Mymensingh Masters', 
    sport: 'badminton', 
    format: 'Singles', 
    date: '2024-01-17', 
    time: '10:00', 
    venue: 'Indoor Sports Complex',
    status: 'live',
    startTime: new Date('2024-01-17T10:00:00').getTime(),
    scorecard: {
      team1Score: '21',
      team2Score: '18',
      overs: '2nd Set',
      status: 'Live - 2nd Set in Progress'
    },
    squads: {
      team1: ['Rupa Akter'],
      team2: ['Opponent 1']
    }
  },
  { 
    id: 4, 
    team1: 'Kishoreganj Spikers', 
    team2: 'Netrokona Warriors', 
    sport: 'volleyball', 
    format: 'Indoor', 
    date: '2024-01-18', 
    time: '15:00', 
    venue: 'Volleyball Arena',
    status: 'completed',
    startTime: new Date('2024-01-18T15:00:00').getTime(),
    scorecard: {
      team1Score: '3',
      team2Score: '1',
      overs: 'Final',
      status: 'Match Completed - Kishoreganj Spikers Won'
    },
    squads: {
      team1: ['Mita Begum', 'Player 2', 'Player 3', 'Player 4', 'Player 5'],
      team2: ['Player 1', 'Player 2', 'Player 3', 'Player 4', 'Player 5']
    }
  }
]

const MatchDetailModal = ({ match, onClose }) => (
  <Dialog open={!!match} onOpenChange={onClose}>
    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="text-2xl font-bold">{match?.team1} vs {match?.team2}</DialogTitle>
      </DialogHeader>
      <div className="space-y-6">
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h3 className="text-lg font-semibold">{match?.team1}</h3>
              <p className="text-2xl font-bold">{match?.scorecard?.team1Score}</p>
            </div>
            <div className="text-center">
              <Badge variant={match?.status === 'live' ? 'destructive' : match?.status === 'completed' ? 'secondary' : 'outline'}>
                {match?.status === 'live' ? <><Play className="h-3 w-3 mr-1" /> LIVE</> : match?.status === 'completed' ? 'Completed' : 'Upcoming'}
              </Badge>
              <p className="text-sm text-gray-600 mt-1">{match?.scorecard?.overs}</p>
            </div>
            <div className="text-right">
              <h3 className="text-lg font-semibold">{match?.team2}</h3>
              <p className="text-2xl font-bold">{match?.scorecard?.team2Score}</p>
            </div>
          </div>
          <p className="text-center text-gray-600">{match?.scorecard?.status}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-lg font-semibold mb-3">Match Details</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Sport:</span>
                <Badge variant="outline">{match?.sport}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Format:</span>
                <Badge>{match?.format}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Date:</span>
                <span className="text-sm">{match?.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Time:</span>
                <span className="text-sm">{match?.time}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Venue:</span>
                <span className="text-sm">{match?.venue}</span>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-3">Squads</h3>
            <div className="space-y-3">
              <div>
                <h4 className="font-medium text-sm text-gray-600 mb-1">{match?.team1}</h4>
                <div className="flex flex-wrap gap-1">
                  {match?.squads?.team1?.map((player, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">{player}</Badge>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-medium text-sm text-gray-600 mb-1">{match?.team2}</h4>
                <div className="flex flex-wrap gap-1">
                  {match?.squads?.team2?.map((player, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">{player}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-semibold mb-3">Match Photos</h3>
          <div className="grid grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((index) => (
              <div key={index} className="bg-gray-200 rounded-lg h-32 flex items-center justify-center">
                <span className="text-gray-500 text-sm">Match Photo {index}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

export default function SchedulesPage() {
  const [selectedSport, setSelectedSport] = useState('all')
  const [selectedFormat, setSelectedFormat] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedMatch, setSelectedMatch] = useState(null)

  const filteredSchedules = mockSchedules.filter(schedule => {
    const matchesSport = selectedSport === 'all' || schedule.sport === selectedSport
    const matchesFormat = selectedFormat === 'all' || schedule.format === selectedFormat
    const matchesSearch = schedule.team1.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         schedule.team2.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSport && matchesFormat && matchesSearch
  })

  const sports = ['cricket', 'football', 'badminton', 'volleyball']
  const formats = ['Test', 'T20', 'ODI', 'League', 'Cup', 'Friendly', 'Singles', 'Doubles', 'Mixed Doubles', 'Indoor', 'Beach']

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-green-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <Link href="/" className="text-3xl md:text-4xl font-bold text-gray-900 flex items-center gap-2">
                <Calendar className="h-8 w-8 text-green-600" />
                Kishoreganj Sports
              </Link>
              <p className="text-gray-600 mt-2">Match Schedules</p>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search matches..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-1">
              <Link href="/" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Home
              </Link>
              <Link href="/players" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Players
              </Link>
              <Link href="/teams" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Teams
              </Link>
              <Link href="/rankings" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Rankings
              </Link>
              <Link href="/schedules" className="px-4 py-3 text-sm font-medium text-green-600 bg-green-50 border-b-2 border-green-600 transition-colors">
                Schedules
              </Link>
              <Link href="/news" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                News
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/about" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                About
              </Link>
              <Link href="/contact" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Filters */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters:</span>
            </div>
            
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Select Sport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                {sports.map(sport => (
                  <SelectItem key={sport} value={sport}>{sport.charAt(0).toUpperCase() + sport.slice(1)}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedFormat} onValueChange={setSelectedFormat}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Format" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Formats</SelectItem>
                {formats.map(format => (
                  <SelectItem key={format} value={format}>{format}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedSport('all')
                setSelectedFormat('all')
                setSearchQuery('')
              }}
            >
              Clear Filters
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Match Schedules</h1>
          <p className="text-gray-600">Upcoming and recent matches from Kishoreganj District sports scene</p>
        </div>

        {/* Status Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-green-500 to-green-700 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-2">⏰</div>
              <div className="text-2xl font-bold">{mockSchedules.filter(m => m.status === 'upcoming').length}</div>
              <div className="text-green-100">Upcoming Matches</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-red-500 to-red-700 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-2">🔴</div>
              <div className="text-2xl font-bold">{mockSchedules.filter(m => m.status === 'live').length}</div>
              <div className="text-red-100">Live Matches</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-500 to-blue-700 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-2">✅</div>
              <div className="text-2xl font-bold">{mockSchedules.filter(m => m.status === 'completed').length}</div>
              <div className="text-blue-100">Completed Matches</div>
            </CardContent>
          </Card>
        </div>

        {/* Matches List */}
        <div className="space-y-4">
          {filteredSchedules.map(schedule => (
            <Card key={schedule.id} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedMatch(schedule)}>
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex-1">
                    <div className="text-lg font-semibold">
                      {schedule.team1} vs {schedule.team2}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                      <Badge variant="outline">{schedule.sport}</Badge>
                      <Badge>{schedule.format}</Badge>
                      <span>{schedule.venue}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{schedule.date}</div>
                    <div className="text-sm text-gray-600">{schedule.time}</div>
                    {schedule.status === 'upcoming' && <CountdownTimer matchId={schedule.id} startTime={schedule.startTime} />}
                    {schedule.status === 'live' && (
                      <Badge variant="destructive" className="mt-1">
                        <Play className="h-3 w-3 mr-1" /> LIVE
                      </Badge>
                    )}
                    {schedule.status === 'completed' && (
                      <Badge variant="secondary" className="mt-1">
                        <Pause className="h-3 w-3 mr-1" /> Completed
                      </Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredSchedules.length === 0 && (
          <div className="text-center py-12">
            <Calendar className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No matches found</h3>
            <p className="text-gray-500">Try adjusting your filters or search terms</p>
          </div>
        )}
      </main>

      {/* Match Detail Modal */}
      <MatchDetailModal match={selectedMatch} onClose={() => setSelectedMatch(null)} />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Kishoreganj Sports</h3>
              <p className="text-gray-400">Your comprehensive sports portal for Kishoreganj District</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Home</Link></li>
                <li><Link href="/players" className="hover:text-white">Players</Link></li>
                <li><Link href="/teams" className="hover:text-white">Teams</Link></li>
                <li><Link href="/rankings" className="hover:text-white">Rankings</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sports</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/schedules?sport=cricket" className="hover:text-white">Cricket</Link></li>
                <li><Link href="/schedules?sport=football" className="hover:text-white">Football</Link></li>
                <li><Link href="/schedules?sport=badminton" className="hover:text-white">Badminton</Link></li>
                <li><Link href="/schedules?sport=volleyball" className="hover:text-white">Volleyball</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@kishoreganjsports.com</li>
                <li>Phone: +880 1234-567890</li>
                <li>Kishoreganj District Sports Complex</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 Kishoreganj Sports. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}