'use client'

import { useState } from 'react'
import { Search, Filter, Trophy, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import Link from 'next/link'

const mockRankings = [
  { id: 1, player: 'Rupa Akter', sport: 'badminton', position: 1, points: 2450, change: 'up', type: 'player' },
  { id: 2, player: 'Salam Uddin', sport: 'football', position: 2, points: 2380, change: 'up', type: 'player' },
  { id: 3, player: 'Rahim Khan', sport: 'cricket', position: 3, points: 2290, change: 'down', type: 'player' },
  { id: 4, player: 'Mita Begum', sport: 'volleyball', position: 4, points: 2180, change: 'same', type: 'player' },
  { id: 5, player: 'Jamal Hossain', sport: 'football', position: 5, points: 2050, change: 'up', type: 'player' },
  { id: 6, player: 'Kishoreganj Tigers', sport: 'cricket', position: 1, points: 2850, change: 'up', type: 'team' },
  { id: 7, player: 'Kishoreganj United', sport: 'football', position: 2, points: 2720, change: 'same', type: 'team' },
  { id: 8, player: 'Kishoreganj Smashers', sport: 'badminton', position: 1, points: 2650, change: 'up', type: 'team' },
  { id: 9, player: 'Kishoreganj Spikers', sport: 'volleyball', position: 1, points: 2580, change: 'up', type: 'team' }
]

export default function RankingsPage() {
  const [rankingType, setRankingType] = useState('all')
  const [rankingFilter, setRankingFilter] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')

  const filteredRankings = mockRankings.filter(ranking => {
    const matchesType = rankingType === 'all' || ranking.type === rankingType
    const matchesSport = rankingFilter === 'all' || ranking.sport === rankingFilter
    const matchesSearch = ranking.player.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesType && matchesSport && matchesSearch
  })

  const getRankingIcon = (position) => {
    switch (position) {
      case 1:
        return '🥇'
      case 2:
        return '🥈'
      case 3:
        return '🥉'
      default:
        return `#${position}`
    }
  }

  const getChangeIcon = (change) => {
    switch (change) {
      case 'up':
        return '📈'
      case 'down':
        return '📉'
      default:
        return '➡️'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-green-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <Link href="/" className="text-3xl md:text-4xl font-bold text-gray-900 flex items-center gap-2">
                <Trophy className="h-8 w-8 text-green-600" />
                Kishoreganj Sports
              </Link>
              <p className="text-gray-600 mt-2">Rankings & Standings</p>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search rankings..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-1">
              <Link href="/" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Home
              </Link>
              <Link href="/players" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Players
              </Link>
              <Link href="/teams" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Teams
              </Link>
              <Link href="/rankings" className="px-4 py-3 text-sm font-medium text-green-600 bg-green-50 border-b-2 border-green-600 transition-colors">
                Rankings
              </Link>
              <Link href="/schedules" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Schedules
              </Link>
              <Link href="/news" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                News
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/about" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                About
              </Link>
              <Link href="/contact" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Filters */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters:</span>
            </div>
            
            <Select value={rankingType} onValueChange={setRankingType}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Ranking Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Rankings</SelectItem>
                <SelectItem value="player">Players</SelectItem>
                <SelectItem value="team">Teams</SelectItem>
              </SelectContent>
            </Select>

            <Select value={rankingFilter} onValueChange={setRankingFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter By" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                <SelectItem value="cricket">Cricket</SelectItem>
                <SelectItem value="football">Football</SelectItem>
                <SelectItem value="badminton">Badminton</SelectItem>
                <SelectItem value="volleyball">Volleyball</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setRankingType('all')
                setRankingFilter('all')
                setSearchQuery('')
              }}
            >
              Clear Filters
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Sports Rankings</h1>
          <p className="text-gray-600">Current rankings and standings for players and teams in Kishoreganj District</p>
        </div>

        {/* Rankings Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-yellow-400 to-yellow-600 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-2">🥇</div>
              <div className="text-2xl font-bold">Top Players</div>
              <div className="text-yellow-100">Best performing athletes</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-blue-500 to-blue-700 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-2">🏆</div>
              <div className="text-2xl font-bold">Team Rankings</div>
              <div className="text-blue-100">Leading teams by sport</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gradient-to-br from-green-500 to-green-700 text-white">
            <CardContent className="p-6 text-center">
              <div className="text-3xl mb-2">📊</div>
              <div className="text-2xl font-bold">Live Updates</div>
              <div className="text-green-100">Real-time ranking changes</div>
            </CardContent>
          </Card>
        </div>

        {/* Rankings List */}
        <div className="space-y-4">
          {filteredRankings.map((ranking, index) => (
            <Card key={ranking.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="flex items-center justify-between p-6">
                <div className="flex items-center gap-6">
                  <div className="text-4xl font-bold text-gray-300">
                    {getRankingIcon(ranking.position)}
                  </div>
                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="text-xl font-semibold">{ranking.player}</h3>
                      <Badge variant="outline" className="capitalize">{ranking.sport}</Badge>
                      <Badge variant={ranking.type === 'player' ? 'default' : 'secondary'}>
                        {ranking.type === 'player' ? <Users className="h-3 w-3 mr-1" /> : <Trophy className="h-3 w-3 mr-1" />}
                        {ranking.type}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      {ranking.type === 'player' ? 'Individual Athlete' : 'Team Performance'}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <div className="text-3xl font-bold text-blue-600">{ranking.points}</div>
                    <div className="text-sm text-gray-600">points</div>
                  </div>
                  <div className="flex flex-col items-center gap-1">
                    <div className="text-2xl">{getChangeIcon(ranking.change)}</div>
                    <div className={`text-xs px-2 py-1 rounded-full ${
                      ranking.change === 'up' ? 'bg-green-100 text-green-700' : 
                      ranking.change === 'down' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {ranking.change === 'up' ? 'Rising' : ranking.change === 'down' ? 'Falling' : 'Steady'}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredRankings.length === 0 && (
          <div className="text-center py-12">
            <Trophy className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No rankings found</h3>
            <p className="text-gray-500">Try adjusting your filters or search terms</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Kishoreganj Sports</h3>
              <p className="text-gray-400">Your comprehensive sports portal for Kishoreganj District</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Home</Link></li>
                <li><Link href="/players" className="hover:text-white">Players</Link></li>
                <li><Link href="/teams" className="hover:text-white">Teams</Link></li>
                <li><Link href="/rankings" className="hover:text-white">Rankings</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sports</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/rankings?type=player&sport=cricket" className="hover:text-white">Cricket</Link></li>
                <li><Link href="/rankings?type=player&sport=football" className="hover:text-white">Football</Link></li>
                <li><Link href="/rankings?type=player&sport=badminton" className="hover:text-white">Badminton</Link></li>
                <li><Link href="/rankings?type=player&sport=volleyball" className="hover:text-white">Volleyball</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@kishoreganjsports.com</li>
                <li>Phone: +880 1234-567890</li>
                <li>Kishoreganj District Sports Complex</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 Kishoreganj Sports. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}