import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Kishoreganj Sports - District Sports Portal",
  description: "The ultimate sports portal for Kishoreganj District featuring players, teams, rankings, schedules, and latest sports news across all sports including Cricket, Football, Badminton, Volleyball and more.",
  keywords: ["Kishoreganj Sports", "District Sports", "Cricket", "Football", "Badminton", "Volleyball", "Sports News", "Player Rankings", "Team Information"],
  authors: [{ name: "Kishoreganj Sports" }],
  openGraph: {
    title: "Kishoreganj Sports",
    description: "Your comprehensive sports portal for Kishoreganj District",
    url: "https://kishoreganj-sports.com",
    siteName: "Kishoreganj Sports",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Kishoreganj Sports",
    description: "Comprehensive sports portal for Kishoreganj District",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
