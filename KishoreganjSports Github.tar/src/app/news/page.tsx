'use client'

import { useState } from 'react'
import { Search, Filter, Newspaper, Calendar, Eye } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import Link from 'next/link'

const mockNews = [
  { 
    id: 1, 
    title: 'Kishoreganj Tigers Win Championship Trophy', 
    sport: 'cricket', 
    excerpt: 'In a thrilling final match, Kishoreganj Tigers defeated their rivals to lift the championship trophy in a nail-biting finish that kept spectators on the edge of their seats until the last ball...', 
    date: '2024-01-10',
    author: 'Sports Correspondent',
    readTime: '5 min read',
    views: 1250,
    image: '/api/placeholder/400/200',
    content: 'Full article content would go here...'
  },
  { 
    id: 2, 
    title: 'Rupa Akter Represents Bangladesh in International Tournament', 
    sport: 'badminton', 
    excerpt: 'Our star badminton player Rupa Akter has been selected to represent Bangladesh in the upcoming international badminton tournament, bringing pride to Kishoreganj District...', 
    date: '2024-01-08',
    author: 'Sports Desk',
    readTime: '3 min read',
    views: 890,
    image: '/api/placeholder/400/200',
    content: 'Full article content would go here...'
  },
  { 
    id: 3, 
    title: 'New Sports Complex Inauguration Ceremony', 
    sport: 'general', 
    excerpt: 'The state-of-the-art sports complex in Kishoreganj was inaugurated yesterday, featuring modern facilities including indoor courts, gymnasium, and Olympic-standard equipment...', 
    date: '2024-01-05',
    author: 'Local Reporter',
    readTime: '4 min read',
    views: 1560,
    image: '/api/placeholder/400/200',
    content: 'Full article content would go here...'
  },
  { 
    id: 4, 
    title: 'Football League Season Kickoff: Exciting Matches Ahead', 
    sport: 'football', 
    excerpt: 'The Kishoreganj District Football League is set to begin next week with promising young talent and experienced veterans ready to showcase their skills in what promises to be an exciting season...', 
    date: '2024-01-03',
    author: 'Football Analyst',
    readTime: '6 min read',
    views: 2100,
    image: '/api/placeholder/400/200',
    content: 'Full article content would go here...'
  },
  { 
    id: 5, 
    title: 'Volleyball Tournament Promotes Women\'s Sports in District', 
    sport: 'volleyball', 
    excerpt: 'A special volleyball tournament was organized to promote women\'s sports participation in Kishoreganj District, with teams from various educational institutions competing for the championship title...', 
    date: '2024-01-01',
    author: 'Women Sports Correspondent',
    readTime: '4 min read',
    views: 980,
    image: '/api/placeholder/400/200',
    content: 'Full article content would go here...'
  },
  { 
    id: 6, 
    title: 'Young Cricket Talent Identification Camp Successful', 
    sport: 'cricket', 
    excerpt: 'The district cricket association successfully conducted a talent identification camp that discovered several promising young players who could represent Kishoreganj in future tournaments...', 
    date: '2023-12-28',
    author: 'Youth Sports Reporter',
    readTime: '5 min read',
    views: 1450,
    image: '/api/placeholder/400/200',
    content: 'Full article content would go here...'
  }
]

export default function NewsPage() {
  const [selectedSport, setSelectedSport] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')

  const filteredNews = mockNews.filter(news => {
    const matchesSport = selectedSport === 'all' || news.sport === selectedSport || news.sport === 'general'
    const matchesSearch = news.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         news.excerpt.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSport && matchesSearch
  })

  const sports = ['cricket', 'football', 'badminton', 'volleyball', 'general']

  const getSportColor = (sport) => {
    switch (sport) {
      case 'cricket': return 'bg-blue-100 text-blue-800'
      case 'football': return 'bg-green-100 text-green-800'
      case 'badminton': return 'bg-red-100 text-red-800'
      case 'volleyball': return 'bg-purple-100 text-purple-800'
      case 'general': return 'bg-gray-100 text-gray-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-green-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <Link href="/" className="text-3xl md:text-4xl font-bold text-gray-900 flex items-center gap-2">
                <Newspaper className="h-8 w-8 text-green-600" />
                Kishoreganj Sports
              </Link>
              <p className="text-gray-600 mt-2">Latest Sports News</p>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search news..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-1">
              <Link href="/" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Home
              </Link>
              <Link href="/players" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Players
              </Link>
              <Link href="/teams" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Teams
              </Link>
              <Link href="/rankings" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Rankings
              </Link>
              <Link href="/schedules" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Schedules
              </Link>
              <Link href="/news" className="px-4 py-3 text-sm font-medium text-green-600 bg-green-50 border-b-2 border-green-600 transition-colors">
                News
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/about" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                About
              </Link>
              <Link href="/contact" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Filters */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters:</span>
            </div>
            
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Select Sport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                {sports.map(sport => (
                  <SelectItem key={sport} value={sport}>
                    {sport === 'general' ? 'General News' : sport.charAt(0).toUpperCase() + sport.slice(1)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedSport('all')
                setSearchQuery('')
              }}
            >
              Clear Filters
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Sports News</h1>
          <p className="text-gray-600">Latest updates, match reports, and sports stories from Kishoreganj District</p>
        </div>

        {/* Featured News */}
        {filteredNews.length > 0 && (
          <Card className="mb-8 overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/3">
                <div className="bg-gray-200 h-64 md:h-full flex items-center justify-center">
                  <Newspaper className="h-24 w-24 text-gray-400" />
                </div>
              </div>
              <div className="md:w-2/3 p-6">
                <div className="flex items-center gap-3 mb-3">
                  <Badge className={getSportColor(filteredNews[0].sport)}>
                    {filteredNews[0].sport === 'general' ? 'General' : filteredNews[0].sport.charAt(0).toUpperCase() + filteredNews[0].sport.slice(1)}
                  </Badge>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Calendar className="h-4 w-4" />
                    <span>{filteredNews[0].date}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Eye className="h-4 w-4" />
                    <span>{filteredNews[0].views.toLocaleString()} views</span>
                  </div>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-3">{filteredNews[0].title}</h2>
                <p className="text-gray-600 mb-4">{filteredNews[0].excerpt}</p>
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-500">
                    By {filteredNews[0].author} • {filteredNews[0].readTime}
                  </div>
                  <Button variant="outline" size="sm">Read Full Article</Button>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* News Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNews.slice(1).map(news => (
            <Card key={news.id} className="hover:shadow-lg transition-shadow">
              <div className="bg-gray-200 h-48 flex items-center justify-center">
                <Newspaper className="h-16 w-16 text-gray-400" />
              </div>
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Badge className={getSportColor(news.sport)}>
                    {news.sport === 'general' ? 'General' : news.sport.charAt(0).toUpperCase() + news.sport.slice(1)}
                  </Badge>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Calendar className="h-3 w-3" />
                    <span>{news.date}</span>
                  </div>
                </div>
                <CardTitle className="text-lg leading-tight">{news.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4 text-sm">{news.excerpt}</p>
                <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                  <span>By {news.author}</span>
                  <span>{news.readTime}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Eye className="h-3 w-3" />
                    <span>{news.views.toLocaleString()}</span>
                  </div>
                  <Button variant="outline" size="sm">Read More</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredNews.length === 0 && (
          <div className="text-center py-12">
            <Newspaper className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No news found</h3>
            <p className="text-gray-500">Try adjusting your filters or search terms</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Kishoreganj Sports</h3>
              <p className="text-gray-400">Your comprehensive sports portal for Kishoreganj District</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Home</Link></li>
                <li><Link href="/players" className="hover:text-white">Players</Link></li>
                <li><Link href="/teams" className="hover:text-white">Teams</Link></li>
                <li><Link href="/rankings" className="hover:text-white">Rankings</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sports</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/news?sport=cricket" className="hover:text-white">Cricket</Link></li>
                <li><Link href="/news?sport=football" className="hover:text-white">Football</Link></li>
                <li><Link href="/news?sport=badminton" className="hover:text-white">Badminton</Link></li>
                <li><Link href="/news?sport=volleyball" className="hover:text-white">Volleyball</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@kishoreganjsports.com</li>
                <li>Phone: +880 1234-567890</li>
                <li>Kishoreganj District Sports Complex</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 Kishoreganj Sports. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}