'use client'

import { useState } from 'react'
import { Search, Trophy, Users, Calendar, Newspaper, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import Link from 'next/link'

const mockPlayers = [
  { id: 1, name: 'Rahim Khan', sport: 'cricket', type: 'Batsman', team: 'Kishoreganj Tigers', age: 28, matches: 45, rating: 4.5 },
  { id: 2, name: 'Karim Ahmed', sport: 'cricket', type: 'Bowler', team: 'Kishoreganj Lions', age: 26, matches: 38, rating: 4.2 },
  { id: 3, name: 'Salam Uddin', sport: 'football', type: 'Forward', team: 'Kishoreganj United', age: 24, matches: 52, rating: 4.7 },
  { id: 4, name: 'Jamal Hossain', sport: 'football', type: 'Midfielder', team: 'Kishoreganj City', age: 27, matches: 48, rating: 4.3 },
  { id: 5, name: 'Rupa Akter', sport: 'badminton', type: 'Singles Player', team: 'Kishoreganj Smashers', age: 22, matches: 34, rating: 4.8 },
  { id: 6, name: 'Mita Begum', sport: 'volleyball', type: 'Setter', team: 'Kishoreganj Spikers', age: 25, matches: 41, rating: 4.4 }
]

const mockTeams = [
  { id: 1, name: 'Kishoreganj Tigers', sport: 'cricket', founded: 2015, wins: 32, losses: 13, captain: 'Rahim Khan' },
  { id: 2, name: 'Kishoreganj United', sport: 'football', founded: 2018, wins: 28, losses: 10, captain: 'Salam Uddin' },
  { id: 3, name: 'Kishoreganj Smashers', sport: 'badminton', founded: 2020, wins: 24, losses: 8, captain: 'Rupa Akter' },
  { id: 4, name: 'Kishoreganj Spikers', sport: 'volleyball', founded: 2019, wins: 30, losses: 12, captain: 'Mita Begum' }
]

const mockSchedules = [
  { id: 1, team1: 'Kishoreganj Tigers', team2: 'Kishoreganj Lions', sport: 'cricket', format: 'T20', date: '2024-01-15', time: '14:00', venue: 'Kishoreganj Stadium', status: 'upcoming' },
  { id: 2, team1: 'Kishoreganj United', team2: 'Kishoreganj City', sport: 'football', format: 'League', date: '2024-01-16', time: '16:00', venue: 'District Football Ground', status: 'upcoming' },
  { id: 3, team1: 'Kishoreganj Smashers', team2: 'Mymensingh Masters', sport: 'badminton', format: 'Singles', date: '2024-01-17', time: '10:00', venue: 'Indoor Sports Complex', status: 'live' },
  { id: 4, team1: 'Kishoreganj Spikers', team2: 'Netrokona Warriors', sport: 'volleyball', format: 'Indoor', date: '2024-01-18', time: '15:00', venue: 'Volleyball Arena', status: 'completed' }
]

const mockNews = [
  { id: 1, title: 'Kishoreganj Tigers Win Championship Trophy', sport: 'cricket', excerpt: 'In a thrilling final match, Kishoreganj Tigers defeated their rivals to lift the championship trophy...', date: '2024-01-10' },
  { id: 2, title: 'Rupa Akter Represents Bangladesh in International Tournament', sport: 'badminton', excerpt: 'Our star badminton player Rupa Akter has been selected to represent Bangladesh in the upcoming...', date: '2024-01-08' },
  { id: 3, title: 'New Sports Complex Inauguration Ceremony', sport: 'general', excerpt: 'The state-of-the-art sports complex in Kishoreganj was inaugurated yesterday, featuring modern facilities...', date: '2024-01-05' }
]

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-green-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <Link href="/" className="text-3xl md:text-4xl font-bold text-gray-900 flex items-center gap-2">
                <Trophy className="h-8 w-8 text-green-600" />
                Kishoreganj Sports
              </Link>
              <p className="text-gray-600 mt-2">Your ultimate sports portal for Kishoreganj District</p>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search players, teams, news..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-1">
              <Link href="/" className="px-4 py-3 text-sm font-medium text-green-600 bg-green-50 border-b-2 border-green-600">
                Home
              </Link>
              <div className="relative group">
                <Link href="/players" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors flex items-center gap-1">
                  Players
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </Link>
                <div className="absolute left-0 mt-0 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border">
                  <Link href="/players" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">All Players</Link>
                  <Link href="/players?sport=cricket" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Cricket Players</Link>
                  <Link href="/players?sport=football" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Football Players</Link>
                  <Link href="/players?sport=badminton" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Badminton Players</Link>
                  <Link href="/players?sport=volleyball" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Volleyball Players</Link>
                </div>
              </div>
              <div className="relative group">
                <Link href="/teams" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors flex items-center gap-1">
                  Teams
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </Link>
                <div className="absolute left-0 mt-0 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border">
                  <Link href="/teams" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">All Teams</Link>
                  <Link href="/teams?sport=cricket" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Cricket Teams</Link>
                  <Link href="/teams?sport=football" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Football Teams</Link>
                  <Link href="/teams?sport=badminton" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Badminton Teams</Link>
                  <Link href="/teams?sport=volleyball" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Volleyball Teams</Link>
                </div>
              </div>
              <Link href="/rankings" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Rankings
              </Link>
              <Link href="/schedules" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Schedules
              </Link>
              <Link href="/news" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                News
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/about" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                About
              </Link>
              <Link href="/contact" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Home Page Highlights */}
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Welcome to Kishoreganj Sports</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Your comprehensive sports portal featuring the best athletes, teams, and matches from Kishoreganj District
          </p>
        </div>

        {/* Featured Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Top Players
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold mb-2">{mockPlayers.length}</div>
              <p className="text-green-100">Elite athletes across all sports</p>
              <Link href="/players" className="inline-block mt-3 text-sm underline">View All Players →</Link>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5" />
                Active Teams
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold mb-2">{mockTeams.length}</div>
              <p className="text-blue-100">Competing teams in various sports</p>
              <Link href="/teams" className="inline-block mt-3 text-sm underline">View All Teams →</Link>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Matches
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold mb-2">{mockSchedules.filter(m => m.status === 'upcoming').length}</div>
              <p className="text-purple-100">Exciting matches scheduled</p>
              <Link href="/schedules" className="inline-block mt-3 text-sm underline">View Schedule →</Link>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Newspaper className="h-5 w-5" />
                Latest News
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold mb-2">{mockNews.length}</div>
              <p className="text-orange-100">Recent sports updates</p>
              <Link href="/news" className="inline-block mt-3 text-sm underline">Read News →</Link>
            </CardContent>
          </Card>
        </div>

        {/* Featured Players */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-gray-900">Featured Players</h3>
            <Link href="/players" className="text-green-600 hover:text-green-700 font-medium">View All →</Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {mockPlayers.slice(0, 3).map(player => (
              <Card key={player.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{player.name}</span>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">{player.rating}</span>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Sport:</span>
                      <Badge variant="outline">{player.sport}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Type:</span>
                      <Badge>{player.type}</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Team:</span>
                      <span className="text-sm font-medium">{player.team}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Upcoming Matches */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-gray-900">Upcoming Matches</h3>
            <Link href="/schedules" className="text-green-600 hover:text-green-700 font-medium">View All →</Link>
          </div>
          <div className="space-y-4">
            {mockSchedules.slice(0, 3).map(match => (
              <Card key={match.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex-1">
                      <div className="text-lg font-semibold">
                        {match.team1} vs {match.team2}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                        <Badge variant="outline">{match.sport}</Badge>
                        <Badge>{match.format}</Badge>
                        <span>{match.venue}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold">{match.date}</div>
                      <div className="text-sm text-gray-600">{match.time}</div>
                      {match.status === 'live' && (
                        <Badge variant="destructive" className="mt-1">
                          LIVE
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Latest News */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-gray-900">Latest News</h3>
            <Link href="/news" className="text-green-600 hover:text-green-700 font-medium">View All →</Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {mockNews.map(news => (
              <Card key={news.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{news.title}</CardTitle>
                    <Badge variant="outline">{news.sport}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">{news.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">{news.date}</span>
                    <Button variant="outline" size="sm">Read More</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Kishoreganj Sports</h3>
              <p className="text-gray-400">Your comprehensive sports portal for Kishoreganj District</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Home</Link></li>
                <li><Link href="/players" className="hover:text-white">Players</Link></li>
                <li><Link href="/teams" className="hover:text-white">Teams</Link></li>
                <li><Link href="/rankings" className="hover:text-white">Rankings</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sports</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/players?sport=cricket" className="hover:text-white">Cricket</Link></li>
                <li><Link href="/players?sport=football" className="hover:text-white">Football</Link></li>
                <li><Link href="/players?sport=badminton" className="hover:text-white">Badminton</Link></li>
                <li><Link href="/players?sport=volleyball" className="hover:text-white">Volleyball</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@kishoreganjsports.com</li>
                <li>Phone: +880 1234-567890</li>
                <li>Kishoreganj District Sports Complex</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 Kishoreganj Sports. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}