'use client'

import { useState } from 'react'
import { Search, Filter, Users, Star, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import Link from 'next/link'

const sportsData = {
  cricket: {
    formats: ['Test', 'T20', 'ODI'],
    playerTypes: ['Batsman', 'Bowler', 'All-Rounder', 'Keeper']
  },
  football: {
    formats: ['League', 'Cup', 'Friendly'],
    playerTypes: ['Forward', 'Midfielder', 'Defender', 'Goalkeeper']
  },
  badminton: {
    formats: ['Singles', 'Doubles', 'Mixed Doubles'],
    playerTypes: ['Singles Player', 'Doubles Player']
  },
  volleyball: {
    formats: ['Indoor', 'Beach'],
    playerTypes: ['Setter', 'Outside Hitter', 'Middle Blocker', 'Libero']
  }
}

const mockPlayers = [
  { 
    id: 1, 
    name: 'Rahim Khan', 
    sport: 'cricket', 
    type: 'Batsman', 
    team: 'Kishoreganj Tigers', 
    age: 28, 
    matches: 45, 
    rating: 4.5,
    image: '/api/placeholder/200/200',
    stats: {
      runs: 2450,
      centuries: 8,
      halfCenturies: 15,
      strikeRate: 89.5,
      average: 54.4
    },
    records: [
      'Highest Score: 145 runs',
      'Most Centuries in Season: 5',
      'Best Bowling: 3/28',
      'Player of the Match: 12 times'
    ]
  },
  { 
    id: 2, 
    name: 'Karim Ahmed', 
    sport: 'cricket', 
    type: 'Bowler', 
    team: 'Kishoreganj Lions', 
    age: 26, 
    matches: 38, 
    rating: 4.2,
    image: '/api/placeholder/200/200',
    stats: {
      wickets: 89,
      economy: 3.2,
      bestFigures: '7/32',
      average: 22.4,
      strikeRate: 18.5
    },
    records: [
      'Best Figures: 7/32',
      'Most Wickets in Season: 28',
      'Best Economy: 2.1',
      'Hat-tricks: 3'
    ]
  },
  { 
    id: 3, 
    name: 'Salam Uddin', 
    sport: 'football', 
    type: 'Forward', 
    team: 'Kishoreganj United', 
    age: 24, 
    matches: 52, 
    rating: 4.7,
    image: '/api/placeholder/200/200',
    stats: {
      goals: 34,
      assists: 18,
      yellowCards: 3,
      redCards: 0,
      passAccuracy: 87
    },
    records: [
      'Most Goals in Season: 18',
      'Best Streak: 7 goals in 5 matches',
      'Man of the Match: 15 times',
      'Fastest Goal: 32 seconds'
    ]
  },
  { 
    id: 4, 
    name: 'Jamal Hossain', 
    sport: 'football', 
    type: 'Midfielder', 
    team: 'Kishoreganj City', 
    age: 27, 
    matches: 48, 
    rating: 4.3,
    image: '/api/placeholder/200/200',
    stats: {
      goals: 12,
      assists: 28,
      tackles: 156,
      passAccuracy: 92,
      distanceCovered: 89.5
    },
    records: [
      'Most Assists in Season: 15',
      'Best Pass Accuracy: 96%',
      'Most Tackles: 8 in one match',
      'Player of the Season: 2023'
    ]
  },
  { 
    id: 5, 
    name: 'Rupa Akter', 
    sport: 'badminton', 
    type: 'Singles Player', 
    team: 'Kishoreganj Smashers', 
    age: 22, 
    matches: 34, 
    rating: 4.8,
    image: '/api/placeholder/200/200',
    stats: {
      wins: 28,
      losses: 6,
      tournaments: 8,
      titles: 3,
      worldRanking: 45
    },
    records: [
      'National Champion: 2023',
      'Longest Win Streak: 15 matches',
      'Youngest Champion: 19 years',
      'International Titles: 2'
    ]
  },
  { 
    id: 6, 
    name: 'Mita Begum', 
    sport: 'volleyball', 
    type: 'Setter', 
    team: 'Kishoreganj Spikers', 
    age: 25, 
    matches: 41, 
    rating: 4.4,
    image: '/api/placeholder/200/200',
    stats: {
      assists: 892,
      aces: 34,
      digs: 156,
      blocks: 23,
      serveAccuracy: 94
    },
    records: [
      'Most Assists in Match: 58',
      'Best Serve Accuracy: 98%',
      'Player of the Tournament: 2 times',
      'Team Captain: 2 years'
    ]
  }
]

const PlayerDetailModal = ({ player, onClose }) => (
  <Dialog open={!!player} onOpenChange={onClose}>
    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="text-2xl font-bold">{player?.name}</DialogTitle>
      </DialogHeader>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <div className="bg-gray-100 rounded-lg p-4 text-center">
            <div className="w-32 h-32 mx-auto bg-gray-300 rounded-full mb-4 flex items-center justify-center">
              <Users className="w-16 h-16 text-gray-600" />
            </div>
            <h3 className="text-lg font-semibold">{player?.name}</h3>
            <p className="text-gray-600">{player?.team}</p>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Age:</span>
                <span className="text-sm">{player?.age}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Sport:</span>
                <Badge variant="outline">{player?.sport}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Type:</span>
                <Badge>{player?.type}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Matches:</span>
                <span className="text-sm">{player?.matches}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Rating:</span>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-500" />
                  <span className="text-sm">{player?.rating}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="md:col-span-2 space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-3">Career Statistics</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {Object.entries(player?.stats || {}).map(([key, value]) => (
                <div key={key} className="bg-gray-50 rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-blue-600">{value}</div>
                  <div className="text-sm text-gray-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-3">Records & Achievements</h3>
            <div className="space-y-2">
              {player?.records?.map((record, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">{record}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

export default function PlayersPage() {
  const [selectedSport, setSelectedSport] = useState('all')
  const [selectedPlayerType, setSelectedPlayerType] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedPlayer, setSelectedPlayer] = useState(null)

  const filteredPlayers = mockPlayers.filter(player => {
    const matchesSport = selectedSport === 'all' || player.sport === selectedSport
    const matchesType = selectedPlayerType === 'all' || player.type === selectedPlayerType
    const matchesSearch = player.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         player.team.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSport && matchesType && matchesSearch
  })

  const currentPlayerTypes = selectedSport === 'all' ? [] : sportsData[selectedSport as keyof typeof sportsData]?.playerTypes || []

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-green-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <Link href="/" className="text-3xl md:text-4xl font-bold text-gray-900 flex items-center gap-2">
                <Users className="h-8 w-8 text-green-600" />
                Kishoreganj Sports
              </Link>
              <p className="text-gray-600 mt-2">Players Directory</p>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search players..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-1">
              <Link href="/" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Home
              </Link>
              <div className="relative group">
                <Link href="/players" className="px-4 py-3 text-sm font-medium text-green-600 bg-green-50 border-b-2 border-green-600 flex items-center gap-1">
                  Players
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </Link>
                <div className="absolute left-0 mt-0 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border">
                  <Link href="/players" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">All Players</Link>
                  <Link href="/players?sport=cricket" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Cricket Players</Link>
                  <Link href="/players?sport=football" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Football Players</Link>
                  <Link href="/players?sport=badminton" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Badminton Players</Link>
                  <Link href="/players?sport=volleyball" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Volleyball Players</Link>
                </div>
              </div>
              <Link href="/teams" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Teams
              </Link>
              <Link href="/rankings" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Rankings
              </Link>
              <Link href="/schedules" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Schedules
              </Link>
              <Link href="/news" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                News
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/about" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                About
              </Link>
              <Link href="/contact" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Filters */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters:</span>
            </div>
            
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Select Sport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                <SelectItem value="cricket">Cricket</SelectItem>
                <SelectItem value="football">Football</SelectItem>
                <SelectItem value="badminton">Badminton</SelectItem>
                <SelectItem value="volleyball">Volleyball</SelectItem>
              </SelectContent>
            </Select>

            {currentPlayerTypes.length > 0 && (
              <Select value={selectedPlayerType} onValueChange={setSelectedPlayerType}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Player Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {currentPlayerTypes.map(type => (
                    <SelectItem key={type} value={type}>{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedSport('all')
                setSelectedPlayerType('all')
                setSearchQuery('')
              }}
            >
              Clear Filters
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Players Directory</h1>
          <p className="text-gray-600">Explore all the talented athletes from Kishoreganj District across various sports</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlayers.map(player => (
            <Card key={player.id} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedPlayer(player)}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{player.name}</span>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">{player.rating}</span>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Sport:</span>
                    <Badge variant="outline">{player.sport}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Type:</span>
                    <Badge>{player.type}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Team:</span>
                    <span className="text-sm font-medium">{player.team}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Age:</span>
                    <span className="text-sm">{player.age}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Matches:</span>
                    <span className="text-sm">{player.matches}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredPlayers.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No players found</h3>
            <p className="text-gray-500">Try adjusting your filters or search terms</p>
          </div>
        )}
      </main>

      {/* Player Detail Modal */}
      <PlayerDetailModal player={selectedPlayer} onClose={() => setSelectedPlayer(null)} />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Kishoreganj Sports</h3>
              <p className="text-gray-400">Your comprehensive sports portal for Kishoreganj District</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Home</Link></li>
                <li><Link href="/players" className="hover:text-white">Players</Link></li>
                <li><Link href="/teams" className="hover:text-white">Teams</Link></li>
                <li><Link href="/rankings" className="hover:text-white">Rankings</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sports</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/players?sport=cricket" className="hover:text-white">Cricket</Link></li>
                <li><Link href="/players?sport=football" className="hover:text-white">Football</Link></li>
                <li><Link href="/players?sport=badminton" className="hover:text-white">Badminton</Link></li>
                <li><Link href="/players?sport=volleyball" className="hover:text-white">Volleyball</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@kishoreganjsports.com</li>
                <li>Phone: +880 1234-567890</li>
                <li>Kishoreganj District Sports Complex</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 Kishoreganj Sports. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}