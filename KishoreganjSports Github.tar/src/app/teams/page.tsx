'use client'

import { useState } from 'react'
import { Search, Filter, Users, Trophy, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import Link from 'next/link'

const mockTeams = [
  { 
    id: 1, 
    name: 'Kishoreganj Tigers', 
    sport: 'cricket', 
    founded: 2015, 
    wins: 32, 
    losses: 13, 
    captain: 'Rahim Khan',
    logo: '/api/placeholder/100/100',
    description: 'The most successful cricket team in Kishoreganj District, known for their aggressive batting style and strong team spirit.',
    achievements: [
      'District Champions: 2021, 2022, 2023',
      'Best Team Award: 2022',
      'Fair Play Award: 2021'
    ],
    squad: 18,
    homeGround: 'Kishoreganj Stadium'
  },
  { 
    id: 2, 
    name: 'Kishoreganj United', 
    sport: 'football', 
    founded: 2018, 
    wins: 28, 
    losses: 10, 
    captain: 'Salam Uddin',
    logo: '/api/placeholder/100/100',
    description: 'A rising football powerhouse with young talent and modern playing style.',
    achievements: [
      'League Runners-up: 2023',
      'Best Young Team: 2022',
      'Most Goals Scored: 2023'
    ],
    squad: 22,
    homeGround: 'District Football Ground'
  },
  { 
    id: 3, 
    name: 'Kishoreganj Smashers', 
    sport: 'badminton', 
    founded: 2020, 
    wins: 24, 
    losses: 8, 
    captain: 'Rupa Akter',
    logo: '/api/placeholder/100/100',
    description: 'Elite badminton team producing national level players with world-class training facilities.',
    achievements: [
      'National Club Champions: 2023',
      'Best Development Program: 2022',
      'Most Improved Team: 2021'
    ],
    squad: 12,
    homeGround: 'Indoor Sports Complex'
  },
  { 
    id: 4, 
    name: 'Kishoreganj Spikers', 
    sport: 'volleyball', 
    founded: 2019, 
    wins: 30, 
    losses: 12, 
    captain: 'Mita Begum',
    logo: '/api/placeholder/100/100',
    description: 'Dominant volleyball team known for their tactical play and exceptional teamwork.',
    achievements: [
      'District Champions: 2022, 2023',
      'Best Defensive Team: 2023',
      'Team Spirit Award: 2022'
    ],
    squad: 16,
    homeGround: 'Volleyball Arena'
  }
]

const TeamDetailModal = ({ team, onClose }) => (
  <Dialog open={!!team} onOpenChange={onClose}>
    <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle className="text-2xl font-bold">{team?.name}</DialogTitle>
      </DialogHeader>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <div className="bg-gray-100 rounded-lg p-4 text-center">
            <div className="w-24 h-24 mx-auto bg-gray-300 rounded-full mb-4 flex items-center justify-center">
              <Users className="h-12 h-12 text-gray-600" />
            </div>
            <h3 className="text-lg font-semibold">{team?.name}</h3>
            <p className="text-gray-600">{team?.sport}</p>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Founded:</span>
                <span className="text-sm">{team?.founded}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Captain:</span>
                <span className="text-sm">{team?.captain}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Squad:</span>
                <span className="text-sm">{team?.squad} players</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Home Ground:</span>
                <span className="text-sm">{team?.homeGround}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="md:col-span-2 space-y-6">
          <div>
            <h3 className="text-lg font-semibold mb-3">Team Description</h3>
            <p className="text-gray-700">{team?.description}</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-3">Performance</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-green-50 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-green-600">{team?.wins}</div>
                <div className="text-sm text-gray-600">Wins</div>
              </div>
              <div className="bg-red-50 rounded-lg p-4 text-center">
                <div className="text-3xl font-bold text-red-600">{team?.losses}</div>
                <div className="text-sm text-gray-600">Losses</div>
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-3">Achievements</h3>
            <div className="space-y-2">
              {team?.achievements?.map((achievement, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-3">
                  <div className="flex items-center gap-2">
                    <Trophy className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">{achievement}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

export default function TeamsPage() {
  const [selectedSport, setSelectedSport] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedTeam, setSelectedTeam] = useState(null)

  const filteredTeams = mockTeams.filter(team => {
    const matchesSport = selectedSport === 'all' || team.sport === selectedSport
    const matchesSearch = team.name.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesSport && matchesSearch
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-green-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <Link href="/" className="text-3xl md:text-4xl font-bold text-gray-900 flex items-center gap-2">
                <Users className="h-8 w-8 text-green-600" />
                Kishoreganj Sports
              </Link>
              <p className="text-gray-600 mt-2">Teams Directory</p>
            </div>
            
            {/* Search Bar */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search teams..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-2 w-full"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Bar */}
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex space-x-1">
              <Link href="/" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Home
              </Link>
              <Link href="/players" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Players
              </Link>
              <div className="relative group">
                <Link href="/teams" className="px-4 py-3 text-sm font-medium text-green-600 bg-green-50 border-b-2 border-green-600 flex items-center gap-1">
                  Teams
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </Link>
                <div className="absolute left-0 mt-0 w-48 bg-white rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 border">
                  <Link href="/teams" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">All Teams</Link>
                  <Link href="/teams?sport=cricket" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Cricket Teams</Link>
                  <Link href="/teams?sport=football" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Football Teams</Link>
                  <Link href="/teams?sport=badminton" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Badminton Teams</Link>
                  <Link href="/teams?sport=volleyball" className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-600">Volleyball Teams</Link>
                </div>
              </div>
              <Link href="/rankings" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Rankings
              </Link>
              <Link href="/schedules" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                Schedules
              </Link>
              <Link href="/news" className="px-4 py-3 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 border-b-2 border-transparent hover:border-green-600 transition-colors">
                News
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/about" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                About
              </Link>
              <Link href="/contact" className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-green-600 hover:bg-green-50 rounded-md transition-colors">
                Contact
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Filters */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filters:</span>
            </div>
            
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Select Sport" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sports</SelectItem>
                <SelectItem value="cricket">Cricket</SelectItem>
                <SelectItem value="football">Football</SelectItem>
                <SelectItem value="badminton">Badminton</SelectItem>
                <SelectItem value="volleyball">Volleyball</SelectItem>
              </SelectContent>
            </Select>

            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSelectedSport('all')
                setSearchQuery('')
              }}
            >
              Clear Filters
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Teams Directory</h1>
          <p className="text-gray-600">Discover all the sports teams representing Kishoreganj District across various competitions</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTeams.map(team => (
            <Card key={team.id} className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setSelectedTeam(team)}>
              <CardHeader>
                <CardTitle>{team.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Sport:</span>
                    <Badge variant="outline">{team.sport}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Founded:</span>
                    <span className="text-sm">{team.founded}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Captain:</span>
                    <span className="text-sm font-medium">{team.captain}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">{team.wins}</div>
                      <div className="text-sm text-gray-600">Wins</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">{team.losses}</div>
                      <div className="text-sm text-gray-600">Losses</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredTeams.length === 0 && (
          <div className="text-center py-12">
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No teams found</h3>
            <p className="text-gray-500">Try adjusting your filters or search terms</p>
          </div>
        )}
      </main>

      {/* Team Detail Modal */}
      <TeamDetailModal team={selectedTeam} onClose={() => setSelectedTeam(null)} />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Kishoreganj Sports</h3>
              <p className="text-gray-400">Your comprehensive sports portal for Kishoreganj District</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Home</Link></li>
                <li><Link href="/players" className="hover:text-white">Players</Link></li>
                <li><Link href="/teams" className="hover:text-white">Teams</Link></li>
                <li><Link href="/rankings" className="hover:text-white">Rankings</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Sports</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/teams?sport=cricket" className="hover:text-white">Cricket</Link></li>
                <li><Link href="/teams?sport=football" className="hover:text-white">Football</Link></li>
                <li><Link href="/teams?sport=badminton" className="hover:text-white">Badminton</Link></li>
                <li><Link href="/teams?sport=volleyball" className="hover:text-white">Volleyball</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Email: info@kishoreganjsports.com</li>
                <li>Phone: +880 1234-567890</li>
                <li>Kishoreganj District Sports Complex</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 Kishoreganj Sports. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}